//
//  ViewController.h
//  label长按复制粘贴
//
//  Created by 孙富有 on 2017/9/18.
//  Copyright © 2017年 孙富有. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

